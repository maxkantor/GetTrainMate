import React, { useCallback, useEffect, useId, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { motion, useReducedMotion, AnimatePresence } from 'framer-motion';
import { useAuthContext } from '@/hooks/useAuthContext';
import { useLandingConversion } from '@/contexts/LandingConversionContext';
import { Container } from '@/components/layout/Container';
import { useI18n } from '@/hooks/useI18n';
import { LANDING_SHOWCASE_DECK_FALLBACK } from '@/data/landingShowcaseFallback';
import { fetchLandingShowcase, isLandingShowcaseLive } from '@/services/landingShowcaseService';
import { logLandingShowcase, redactUrlForLog } from '@/utils/landingShowcaseDebug';
import { landingShowcaseImageProps, pickLandingShowcasePhotoUrl } from '@/utils/landingShowcaseImages';
import { NO_PHOTO_PLACEHOLDER } from '@/utils/profilePhotos';
import styles from './SwipeDemoSection.module.css';

type Phase = 'idle' | 'swipe' | 'match';

type DeckProfile = {
  name: string;
  age: number;
  photo: string;
  tags: string[];
  matchPct: number;
};

const FALLBACK_PROFILES: DeckProfile[] = LANDING_SHOWCASE_DECK_FALLBACK.map((p) => ({
  name: p.name,
  age: p.age,
  photo: p.photo,
  tags: p.tags,
  matchPct: p.matchPct,
}));

const IDLE_MS = 3000;
const SWIPE_MS = 580;
const MATCH_MS = 1650;

function MatchBadge({ percent }: { percent: number }) {
  const uid = useId().replace(/:/g, '');
  const gradId = `mdb-${uid}`;
  const r = 18;
  const c = 2 * Math.PI * r;
  const p = Math.max(0, Math.min(100, percent));
  const offset = c - (p / 100) * c;
  return (
    <div className={styles.matchBadge}>
      <svg className={styles.matchSvg} viewBox="0 0 44 44" aria-hidden>
        <defs>
          <linearGradient id={gradId} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#a78bfa" />
            <stop offset="100%" stopColor="#38bdf8" />
          </linearGradient>
        </defs>
        <circle cx="22" cy="22" r={r} fill="none" stroke="rgba(255,255,255,0.12)" strokeWidth="3" />
        <circle
          cx="22"
          cy="22"
          r={r}
          fill="none"
          stroke={`url(#${gradId})`}
          strokeWidth="3"
          strokeLinecap="round"
          strokeDasharray={c}
          strokeDashoffset={offset}
          transform="rotate(-90 22 22)"
        />
        <text x="22" y="26" textAnchor="middle" className={styles.matchNumSvg}>
          {p}%
        </text>
      </svg>
    </div>
  );
}

type FaceProps = {
  profile: DeckProfile;
  depth: 0 | 1 | 2;
  /** Hide name/tags during match overlay so mid-stack copy does not bleed through. */
  hideMeta?: boolean;
  onPhotoError?: (e: React.SyntheticEvent<HTMLImageElement>) => void;
};

function DeckFace({ profile, depth, hideMeta, onPhotoError }: FaceProps) {
  const imgExtras = landingShowcaseImageProps(profile.photo);
  if (depth === 0) {
    return (
      <div className={styles.faceTop}>
        <div className={styles.photoShell}>
          <div className={styles.photoParallax} data-parallax="1">
            <img
              src={profile.photo}
              alt=""
              className={styles.photo}
              width={400}
              height={500}
              loading="lazy"
              {...imgExtras}
              onError={onPhotoError}
            />
          </div>
          <div className={styles.photoScrim} aria-hidden />
        </div>
        {hideMeta ? null : (
          <div className={styles.faceMeta}>
            <div className={styles.nameRow}>
              <span className={styles.name}>
                {profile.name}, {profile.age}
              </span>
              <MatchBadge percent={profile.matchPct} />
            </div>
            <div className={styles.tags}>
              {profile.tags.map((t) => (
                <span key={t} className={styles.tag}>
                  {t}
                </span>
              ))}
            </div>
          </div>
        )}
      </div>
    );
  }
  const layer = depth === 1 ? styles.faceMid : styles.faceBack;
  return (
    <div className={`${styles.face} ${layer}`}>
      <div className={styles.photoShell}>
        <div className={styles.photoParallax}>
          <img
            src={profile.photo}
            alt=""
            className={styles.photo}
            width={400}
            height={500}
            loading="lazy"
            {...imgExtras}
            onError={onPhotoError}
          />
        </div>
        <div className={styles.photoScrim} aria-hidden />
      </div>
      {hideMeta ? null : (
        <div className={styles.faceMeta}>
          <div className={styles.nameRow}>
            <span className={styles.name}>
              {profile.name}, {profile.age}
            </span>
            <MatchBadge percent={profile.matchPct} />
          </div>
          <div className={styles.tags}>
            {profile.tags.map((t) => (
              <span key={t} className={styles.tag}>
                {t}
              </span>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

export const SwipeDemoSection: React.FC = () => {
  const { t } = useI18n();
  const reduceMotion = useReducedMotion();
  const { isAuthenticated } = useAuthContext();
  const { openEntryFlow } = useLandingConversion();
  const [profiles, setProfiles] = useState<DeckProfile[]>(() => [...FALLBACK_PROFILES]);
  const [phase, setPhase] = useState<Phase>('idle');
  const [deckIndex, setDeckIndex] = useState(0);
  const timersRef = useRef<number[]>([]);
  const deckRef = useRef<HTMLDivElement>(null);
  const photoShellRef = useRef<HTMLDivElement>(null);

  const onDeckPhotoError = useCallback((e: React.SyntheticEvent<HTMLImageElement>) => {
    logLandingShowcase('SwipeDemoSection: deck img onError', {
      src: redactUrlForLog(e.currentTarget.currentSrc || e.currentTarget.src),
    });
  }, []);

  useEffect(() => {
    let cancelled = false;
    fetchLandingShowcase().then((data) => {
      if (cancelled || !data) return;
      if (!isLandingShowcaseLive(data) || data.deck.length < 3) {
        logLandingShowcase('SwipeDemoSection: keeping fallback deck', {
          kind: data?.kind,
          deckLen: data?.deck?.length ?? 0,
        });
        return;
      }
      const mapped: DeckProfile[] = data.deck.map((card, i) => {
        const fallback = FALLBACK_PROFILES[i % FALLBACK_PROFILES.length];
        const photoPick = pickLandingShowcasePhotoUrl(card.photoUrl);
        const photo = photoPick !== NO_PHOTO_PLACEHOLDER ? photoPick : fallback.photo;
        const tags =
          card.tags?.filter((t) => t && t.trim().length > 0).map((t) => t.trim()) ?? fallback.tags;
        return {
          name: card.name?.trim() || fallback.name,
          age: card.age ?? fallback.age,
          photo,
          tags: tags.length > 0 ? tags : fallback.tags,
          matchPct: typeof card.matchPct === 'number' ? card.matchPct : fallback.matchPct,
        };
      });
      logLandingShowcase('SwipeDemoSection: applied live deck', {
        names: mapped.map((m) => m.name),
        photos: mapped.map((m) => redactUrlForLog(m.photo)),
      });
      setProfiles(mapped);
    });
    return () => {
      cancelled = true;
    };
  }, []);

  const len = profiles.length;
  const iFront = deckIndex % len;
  const iMid = (deckIndex + 1) % len;
  const iBack = (deckIndex + 2) % len;

  const onDeckParallax = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      if (reduceMotion) return;
      const el = deckRef.current;
      if (!el) return;
      const r = el.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width - 0.5;
      const py = (e.clientY - r.top) / r.height - 0.5;
      el.style.setProperty('--px', String(px * 2));
      el.style.setProperty('--py', String(py * 2));
    },
    [reduceMotion]
  );

  const onDeckParallaxLeave = useCallback(() => {
    const el = deckRef.current;
    if (!el) return;
    el.style.setProperty('--px', '0');
    el.style.setProperty('--py', '0');
  }, []);

  const onPhotoParallax = useCallback(
    (e: React.MouseEvent<HTMLDivElement>) => {
      if (reduceMotion) return;
      const shell = photoShellRef.current;
      if (!shell) return;
      const r = shell.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width - 0.5;
      const py = (e.clientY - r.top) / r.height - 0.5;
      const inner = shell.querySelector('[data-parallax="1"]') as HTMLElement | null;
      if (inner) {
        inner.style.transform = `translate(${px * 18}px, ${py * 12}px) scale(1.08)`;
      }
    },
    [reduceMotion]
  );

  const onPhotoParallaxLeave = useCallback(() => {
    const shell = photoShellRef.current;
    if (!shell) return;
    const inner = shell.querySelector('[data-parallax="1"]') as HTMLElement | null;
    if (inner) inner.style.transform = 'translate(0,0) scale(1.02)';
  }, []);

  useEffect(() => {
    const clearAll = () => {
      timersRef.current.forEach((id) => clearTimeout(id));
      timersRef.current = [];
    };

    const schedule = (fn: () => void, ms: number) => {
      const id = window.setTimeout(fn, ms) as unknown as number;
      timersRef.current.push(id);
    };

    const runCycle = () => {
      clearAll();
      schedule(() => {
        if (reduceMotion) {
          setPhase('match');
          schedule(() => {
            setDeckIndex((d) => (d + 1) % len);
            setPhase('idle');
            runCycle();
          }, MATCH_MS);
          return;
        }

        setPhase('swipe');
        schedule(() => {
          setPhase('match');
          schedule(() => {
            setDeckIndex((d) => (d + 1) % len);
            setPhase('idle');
            runCycle();
          }, MATCH_MS);
        }, SWIPE_MS);
      }, IDLE_MS);
    };

    runCycle();
    return clearAll;
  }, [reduceMotion, len]);

  const showMatch = phase === 'match';

  return (
    <section className={styles.section} id="how-it-works" aria-labelledby="swipe-demo-heading">
      <Container size="wide">
        <div className={styles.sectionHead}>
          <h2 id="swipe-demo-heading" className={styles.title}>
            {t('landing.swipe_demo_title')}
          </h2>
          <p className={styles.subtitle}>{t('landing.swipe_demo_subtitle')}</p>
          <p className={styles.trustLine}>{t('landing.swipe_demo_trust')}</p>
        </div>

        <div
          className={styles.deckZone}
          ref={deckRef}
          onMouseMove={onDeckParallax}
          onMouseLeave={onDeckParallaxLeave}
        >
          <div className={styles.deckParallax}>
            <div className={styles.deckFloat}>
            <div className={styles.stackBehind}>
              <DeckFace profile={profiles[iBack]} depth={2} hideMeta={showMatch} onPhotoError={onDeckPhotoError} />
              <DeckFace profile={profiles[iMid]} depth={1} hideMeta={showMatch} onPhotoError={onDeckPhotoError} />
            </div>

            <motion.div
              key={deckIndex}
              className={`${styles.swipeLayer} ${showMatch ? styles.swipeLayerHidden : ''}`}
              initial={false}
              animate={
                reduceMotion
                  ? { x: 0, rotate: 0, opacity: 1 }
                  : phase === 'swipe'
                    ? {
                        x: [0, 32, 440],
                        rotate: [0, 7, 15],
                        opacity: [1, 1, 0],
                      }
                    : phase === 'match'
                      ? { x: 440, rotate: 15, opacity: 0 }
                      : { x: 0, rotate: 0, opacity: 1 }
              }
              transition={
                phase === 'swipe'
                  ? {
                      duration: SWIPE_MS / 1000,
                      times: [0, 0.2, 1],
                      ease: 'easeInOut',
                    }
                  : { type: 'spring', stiffness: 440, damping: 36 }
              }
            >
              <motion.div
                className={styles.topCard}
                initial={reduceMotion ? false : { opacity: 0, y: 28, scale: 0.9 }}
                animate={{ opacity: 1, y: 0, scale: 1 }}
                transition={{ type: 'spring', stiffness: 400, damping: 26 }}
                whileHover={reduceMotion ? undefined : { y: -8, transition: { duration: 0.22 } }}
              >
                <div
                  ref={photoShellRef}
                  className={styles.topCardInner}
                  onMouseMove={onPhotoParallax}
                  onMouseLeave={onPhotoParallaxLeave}
                >
                  <DeckFace
                    profile={profiles[iFront]}
                    depth={0}
                    hideMeta={showMatch}
                    onPhotoError={onDeckPhotoError}
                  />
                </div>
              </motion.div>
            </motion.div>

            <AnimatePresence>
              {showMatch && (
                <motion.div
                  key="match"
                  className={styles.matchLayer}
                  role="status"
                  aria-live="polite"
                  initial={{ opacity: 0, scale: 0.88 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ type: 'spring', stiffness: 420, damping: 26 }}
                >
                  <div className={styles.matchBurst}>
                    <span className={styles.matchEmoji} aria-hidden>
                      🔥
                    </span>
                    <span className={styles.matchTitle}>{t('landing.swipe_match_title')}</span>
                    <span className={styles.matchHint}>{t('landing.swipe_match_hint')}</span>
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
            </div>
          </div>
        </div>

        <div className={styles.ctaColumn}>
          {!isAuthenticated ? (
            <button type="button" className={styles.cta} onClick={openEntryFlow}>
              {t('landing.landing_primary_cta')}
            </button>
          ) : (
            <Link to="/app/discover" className={styles.cta}>
              {t('landing.landing_primary_cta')}
            </Link>
          )}
          <p className={styles.ctaSub}>{t('landing.landing_cta_sub')}</p>
          <p className={styles.scarcityLine}>{t('landing.landing_scarcity')}</p>
        </div>
      </Container>
    </section>
  );
};
