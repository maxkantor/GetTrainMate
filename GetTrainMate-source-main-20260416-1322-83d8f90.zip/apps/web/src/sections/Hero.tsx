import React from 'react';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { useAuthContext } from '@/hooks/useAuthContext';
import { useMe } from '@/hooks/useMe';
import { useI18n } from '@/hooks/useI18n';
import { useLandingConversion } from '@/contexts/LandingConversionContext';
import { Container } from '@/components/layout/Container';
import { HeroFloatingStack } from '@/components/premium/HeroFloatingStack';
import styles from './sections.module.css';

const ease = [0.16, 1, 0.3, 1] as const;

export const Hero: React.FC = () => {
  const { isAuthenticated } = useAuthContext();
  const { openEntryFlow } = useLandingConversion();
  const { me } = useMe();
  const { t } = useI18n();

  const profileComplete = me?.isProfileComplete ?? true;
  const ctaPrimaryHref = !isAuthenticated
    ? '/signup'
    : !profileComplete
      ? '/onboarding/profile'
      : '/app';
  const primaryCta = t('landing.landing_primary_cta');
  const ctaPrimaryLabel = !isAuthenticated
    ? primaryCta
    : !profileComplete
      ? t('landing.cta_finish_profile')
      : t('nav.dashboard');
  const showCtaSubtext = profileComplete;
  const primaryOpensFlow = !isAuthenticated && ctaPrimaryLabel === primaryCta;

  return (
    <section className={styles.heroPremium}>
      <div className={styles.heroPremiumBg} aria-hidden />
      <div className={styles.heroGrain} aria-hidden />
      <div className={styles.heroRadialAccent} aria-hidden />

      <Container size="wide">
        <div className={styles.heroPremiumGrid}>
          <div className={styles.heroPremiumLeft}>
            <motion.h1
              className={styles.heroPremiumTitle}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, ease }}
            >
              {t('landing.hero_premium_title')}
            </motion.h1>
            <motion.p
              className={styles.heroPremiumSub}
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.55, ease, delay: 0.06 }}
            >
              {t('landing.hero_premium_sub')}
            </motion.p>
            <motion.div
              className={styles.heroPremiumCtas}
              initial={{ opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, ease, delay: 0.12 }}
            >
              <div className={styles.heroPrimaryStack}>
                {primaryOpensFlow ? (
                  <button type="button" className={styles.heroBtnPrimary} onClick={openEntryFlow}>
                    {ctaPrimaryLabel}
                  </button>
                ) : (
                  <Link to={ctaPrimaryHref} className={styles.heroBtnPrimary}>
                    {ctaPrimaryLabel}
                  </Link>
                )}
                {primaryOpensFlow && (
                  <span className={styles.heroCtaSub}>{t('landing.landing_hero_sub_guest')}</span>
                )}
                {!primaryOpensFlow && showCtaSubtext && (
                  <>
                    <span className={styles.heroCtaSub}>{t('landing.landing_cta_sub')}</span>
                    <span className={styles.heroScarcityLine}>{t('landing.landing_scarcity')}</span>
                  </>
                )}
              </div>
              <a href="#how-it-works" className={`${styles.heroBtnGhost} ${styles.landingLinkUnderline}`}>
                {t('landing.hero_see_how')}
              </a>
            </motion.div>
            <motion.p
              className={styles.heroEmotionalHook}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, ease, delay: 0.14 }}
            >
              {t('landing.hero_hook')}
            </motion.p>
            <motion.div
              className={styles.heroExclusivity}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.45, ease, delay: 0.14 }}
            >
              <span className={styles.heroExclusivityBadge}>{t('landing.hero_badge_serious')}</span>
              <p className={styles.heroExclusivityLine}>{t('landing.hero_exclusivity_line')}</p>
            </motion.div>
            <motion.ul
              className={styles.socialProof}
              initial={{ opacity: 0, y: 12 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.5, ease, delay: 0.18 }}
              aria-label={t('landing.hero_proof_aria')}
            >
              <li>{t('landing.hero_proof_1')}</li>
              <li>{t('landing.hero_proof_2')}</li>
              <li>{t('landing.hero_proof_3')}</li>
            </motion.ul>
            <motion.p
              className={styles.heroFomoLine}
              initial={{ opacity: 0.85 }}
              animate={{ opacity: 1 }}
              transition={{ duration: 0.4 }}
            >
              {t('landing.hero_fomo')}
            </motion.p>
          </div>

          <motion.div
            className={styles.heroPremiumRight}
            initial={{ opacity: 0, scale: 0.96, y: 16 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 0.65, ease, delay: 0.1 }}
          >
            <HeroFloatingStack />
          </motion.div>
        </div>
      </Container>
    </section>
  );
};
