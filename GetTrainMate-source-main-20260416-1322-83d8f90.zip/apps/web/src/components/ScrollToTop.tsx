import React, { useEffect } from 'react';
import { useLocation } from 'react-router-dom';

/** Scroll to top when route changes (pathname or query) */
export const ScrollToTop: React.FC = () => {
  const { pathname, search } = useLocation();

  useEffect(() => {
    window.scrollTo({ top: 0, left: 0, behavior: 'smooth' });
  }, [pathname, search]);

  return null;
};
