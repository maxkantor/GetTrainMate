using Amazon.DynamoDBv2;
using Amazon.DynamoDBv2.DocumentModel;
using Amazon.DynamoDBv2.Model;
using GetTrainMate.Api.Constants;
using GetTrainMate.Api.Models;
using System.Collections.Concurrent;
using System.Globalization;
using System.Linq;
using System.Text.Json;
using System.Threading;

namespace GetTrainMate.Api.Services;

public class MatchService : IMatchService
{
    private readonly IAmazonDynamoDB _dynamoDb;
    private readonly IProfileService _profileService;
    private readonly IStorageService _storageService;
    private readonly ICreditsService _creditsService;
    private readonly string _matchesTable;
    private readonly string _profilesTable;
    private readonly string _discoverPassesTable;
    private readonly string _userInteractionsTable;
    private readonly string _chatThreadsTable;
    private readonly string _messagesTable;
    private readonly ILogger<MatchService> _logger;

    private static readonly ConcurrentDictionary<string, long> LastUserInteractionSyncMs = new();

    // Scoring weights for compatibility
    private const int SportsMatchWeight = 30;
    private const int ScheduleMatchWeight = 25;
    private const int LevelMatchWeight = 20;
    private const int DistanceWeight = 15;
    private const int ModeMatchWeight = 10;
    private const string AdminControlsPartitionKey = "__discover_controls__";
    private const string AdminControlsSortKey = "admin";
    private const string AdminProfileStatusPartitionKey = "__discover_profile_status__";
    /// <summary>Sent / Skipped review lists: most recent N only (UI + payload size).</summary>
    private const int RelationshipListLimit = 30;

    public MatchService(
        IAmazonDynamoDB dynamoDb,
        IProfileService profileService,
        IStorageService storageService,
        ICreditsService creditsService,
        IConfiguration configuration,
        ILogger<MatchService> logger)
    {
        _dynamoDb = dynamoDb;
        _profileService = profileService;
        _storageService = storageService;
        _creditsService = creditsService;
        var prefix = configuration["DYNAMODB_TABLE_PREFIX"] ?? "gettrainmate-";
        _matchesTable = configuration["DYNAMODB_TABLE_MATCHES"] ?? $"{prefix}matches";
        _profilesTable = configuration["DYNAMODB_TABLE_PROFILES"] ?? $"{prefix}profiles";
        _discoverPassesTable = configuration["DYNAMODB_TABLE_DISCOVER_PASSES"] ?? $"{prefix}discover-passes";
        _userInteractionsTable = configuration["DYNAMODB_TABLE_USER_INTERACTIONS"] ?? $"{prefix}user-interactions";
        _chatThreadsTable = configuration["DYNAMODB_TABLE_CHAT_THREADS"] ?? $"{prefix}chat-threads";
        _messagesTable = configuration["DYNAMODB_TABLE_MESSAGES"] ?? $"{prefix}messages";
        _logger = logger;
    }

    /// <summary>
    /// Seeds demo profiles so Discover is not empty. These are fake users (e.g. "Alex Hyrox")
    /// for development and first-time experience. Order in the feed depends on DB/scan.
    /// </summary>
    public async Task<int> SeedDemoProfilesAsync()
    {
        // Only 3 seed profiles with real photos so real user-created profiles (Max, Alex, Sasha, etc.) dominate the feed
        var dummyUsers = new[]
        {
            new { UserId = "dummy-user-1", Name = "Sarah Runner", City = "San Francisco", Bio = "Marathon runner looking for training partners. Love long runs on weekends!", SportTags = new[] { "Running", "Yoga", "Hiking" }, Level = "intermediate", Goals = new[] { "Complete a sub-4 hour marathon" }, AvailabilitySchedule = new[] { new AvailabilitySlot { Days = new List<string> { "Mon", "Wed", "Fri" }, TimeStart = "18:00", TimeEnd = "20:00" } }, Mode = "TRAIN" },
            new { UserId = "dummy-user-2", Name = "Mike Cyclist", City = "San Francisco", Bio = "Cycling enthusiast. Looking for weekend ride buddies.", SportTags = new[] { "Cycling", "Gym", "CrossFit" }, Level = "advanced", Goals = new[] { "Complete a century ride" }, AvailabilitySchedule = new[] { new AvailabilitySlot { Days = new List<string> { "Sat", "Sun" }, TimeStart = "08:00", TimeEnd = "12:00" } }, Mode = "VIBE" },
            new { UserId = "dummy-user-3", Name = "Emma Yoga", City = "San Francisco", Bio = "Yoga instructor and fitness enthusiast. Love morning yoga sessions!", SportTags = new[] { "Yoga", "Pilates", "Meditation" }, Level = "pro", Goals = new[] { "Build a yoga community" }, AvailabilitySchedule = new[] { new AvailabilitySlot { Days = new List<string> { "Mon", "Wed", "Fri" }, TimeStart = "06:00", TimeEnd = "08:00" } }, Mode = "VIBE" },
        };

        var created = 0;
        foreach (var user in dummyUsers)
        {
            try
            {
                var existing = await _profileService.GetProfileAsync(user.UserId);
                if (existing != null) continue;

                var profile = new UserProfile
                {
                    UserId = user.UserId,
                    Email = $"{user.UserId}@test.com",
                    Name = user.Name,
                    City = user.City,
                    Bio = user.Bio,
                    SportTags = user.SportTags.ToList(),
                    Level = user.Level,
                    Goals = user.Goals.ToList(),
                    AvailabilitySchedule = user.AvailabilitySchedule.ToList(),
                    Mode = user.Mode,
                    Modes = new List<string> { user.Mode },
                    PhotoUrls = DummyProfilePhotos.GetPhotoUrls(user.UserId),
                    IsComplete = true,
                    CreatedAt = DateTime.UtcNow,
                    UpdatedAt = DateTime.UtcNow,
                };
                await _profileService.CreateProfileAsync(profile);
                created++;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Seed demo: could not create {UserId}", user.UserId);
            }
        }
        if (created > 0)
            _logger.LogInformation("Seeded {Count} demo profiles for discovery", created);
        return created;
    }

    public async Task<CompatibilityInfo?> GetCompatibilityAsync(string userId, string targetUserId)
    {
        if (string.IsNullOrEmpty(targetUserId)) return null;
        var userProfile = await _profileService.GetProfileAsync(userId);
        var targetProfile = await _profileService.GetProfileAsync(targetUserId);
        if (userProfile == null || targetProfile == null) return null;
        var score = CalculateCompatibilityScore(userProfile, targetProfile);
        var commonSports = GetCommonSports(userProfile.SportTags, targetProfile.SportTags);
        return new CompatibilityInfo
        {
            CompatibilityScore = score,
            CommonSports = commonSports,
            Level = targetProfile.Level,
            City = targetProfile.City,
            Mode = targetProfile.Mode,
            Modes = ProfileModes.GetNormalizedModes(targetProfile)
        };
    }

    public async Task<List<MatchFeedItem>> GetDiscoveryFeedAsync(string userId, int limit = 20, bool ignoreSkippedForAdmin = false)
    {
        try
        {
            await EnsureLegacyInteractionsSyncedForUserAsync(userId);
            var userProfile = await _profileService.GetProfileAsync(userId);
            // Return other profiles even when current user has no profile (e.g. new account, eventual consistency)

            var table = Table.LoadTable(_dynamoDb, _profilesTable);
            var scanFilter = new ScanFilter();
            
            // Get all profiles (in production, use GSI for better performance)
            var search = table.Scan(scanFilter);
            var allProfiles = new List<Document>();
            
            do
            {
                var batch = await search.GetNextSetAsync();
                allProfiles.AddRange(batch);
            } while (!search.IsDone);

            var feedItems = new List<MatchFeedItem>();
            var passedTargetIds = await GetPassedTargetUserIdsAsync(userId);
            var excludedLikedOrMatched = await GetUserIdsExcludedFromDiscoverByMatchesAsync(userId);
            var adminProfileStatusMap = await GetAdminProfileStatusMapAsync();

            var recycleSkipped = userProfile?.DiscoverCanRecycleSkippedProfiles == true;
            var replayQueue = userProfile?.DiscoverCanReplayDiscoverQueue == true;
            var showSkippedAgain = ignoreSkippedForAdmin || recycleSkipped || replayQueue;

            // Pass 0: require overlapping TRAIN/VIBE/DATE intent. Pass 1 (only if pass 0 is empty): show others so a
            // small pool + mismatched modes (e.g. DATE vs TRAIN only) does not leave Discover permanently empty.
            for (var intentPass = 0; intentPass < 2; intentPass++)
            {
                if (intentPass == 1)
                    feedItems.Clear();

                foreach (var doc in allProfiles)
                {
                    if (!doc.ContainsKey("userId"))
                    {
                        _logger.LogDebug("Discovery feed: skipping profile document without userId");
                        continue;
                    }
                    var profileUserId = doc["userId"].AsString();
                    if (string.IsNullOrEmpty(profileUserId))
                        continue;

                    // Skip only self so Discover shows all other profiles (Max sees Alex, Sasha, etc.)
                    if (profileUserId == userId)
                        continue;

                    if (excludedLikedOrMatched.Contains(profileUserId))
                        continue;

                    var wasPassed = passedTargetIds.Contains(profileUserId);
                    if (wasPassed && !showSkippedAgain)
                        continue;

                    var seenBefore = wasPassed && showSkippedAgain;

                    if (adminProfileStatusMap.TryGetValue(profileUserId, out var profileStatus))
                    {
                        if (string.Equals(profileStatus, "hidden", StringComparison.OrdinalIgnoreCase))
                            continue;
                        if (!ignoreSkippedForAdmin && string.Equals(profileStatus, "skipped", StringComparison.OrdinalIgnoreCase))
                            continue;
                    }

                    UserProfile targetProfile;
                    try
                    {
                        targetProfile = DocumentToProfile(doc);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Discovery feed: skipping profile document for userId {UserId}", profileUserId);
                        continue;
                    }

                    var intentOverlap = userProfile == null || ProfileModes.HasIntentOverlap(userProfile, targetProfile);
                    if (userProfile != null && !intentOverlap && intentPass == 0)
                        continue;

                    var compatibilityScore = userProfile != null
                        ? CalculateCompatibilityScore(userProfile, targetProfile)
                        : 50;

                    var distanceKm = userProfile != null
                        ? CalculateDistance(userProfile.Latitude, userProfile.Longitude, targetProfile.Latitude, targetProfile.Longitude)
                        : double.MaxValue;
                    string intentTier;
                    if (userProfile == null)
                        intentTier = "unknown";
                    else if (!intentOverlap)
                        intentTier = "relaxed";
                    else if (ProfileModes.IsExactIntentAlignment(userProfile, targetProfile))
                        intentTier = "exact";
                    else
                        intentTier = "overlap";

                    var (previewReasons, lockedReasons) = userProfile != null
                        ? BuildMatchInsightReasons(userProfile, targetProfile, distanceKm)
                        : (new List<string>(), new List<string> { "🔒 Strength compatibility", "🔒 Training rhythm", "🔒 Personality fit" });

                    if (intentTier == "relaxed" && previewReasons.Count == 0)
                        previewReasons = new List<string> { "Add overlapping intent modes on Profile (Train / Vibe / Date) for tighter matches." };

                    var photoUrls = ResolvePhotoUrlsForProfile(targetProfile);

                    feedItems.Add(new MatchFeedItem
                    {
                        UserId = targetProfile.UserId,
                        Name = targetProfile.Name ?? "User",
                        City = targetProfile.City,
                        Bio = targetProfile.Bio,
                        SportTags = targetProfile.SportTags,
                        Level = targetProfile.Level,
                        PhotoUrls = photoUrls,
                        CompatibilityScore = compatibilityScore,
                        CommonSports = userProfile != null ? GetCommonSports(userProfile.SportTags, targetProfile.SportTags) : new List<string>(),
                        Mode = targetProfile.Mode,
                        Modes = ProfileModes.GetNormalizedModes(targetProfile),
                        IntentMatchTier = intentTier,
                        MatchPreviewReasons = previewReasons,
                        LockedInsightReasons = lockedReasons,
                        SeenBefore = seenBefore
                    });
                }

                if (feedItems.Count > 0)
                {
                    if (intentPass == 1)
                    {
                        _logger.LogInformation(
                            "Discovery feed: relaxed intent pass used for user {UserId} (no strict TRAIN/VIBE/DATE overlap with anyone in pool)",
                            userId);
                    }

                    break;
                }
            }

            return feedItems
                .OrderByDescending(x => x.IntentMatchTier == "exact" ? 3 : x.IntentMatchTier == "overlap" ? 2 : x.IntentMatchTier == "relaxed" ? 1 : 0)
                .ThenByDescending(x => x.CompatibilityScore)
                .Take(limit)
                .ToList();
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting discovery feed for user {UserId}", userId);
            throw;
        }
    }

    /// <summary>
    /// Records a one-sided like on the match row. <see cref="Match.IsMatched"/> is true only when both
    /// <see cref="Match.User1Liked"/> and <see cref="Match.User2Liked"/> are true (mutual interest).
    /// </summary>
    public async Task<MatchResponse> LikeUserAsync(string userId, string targetUserId)
    {
        await _creditsService.ChargeLikeForDiscoverAsync(userId, targetUserId);

        try
        {
            var existingMatch = await GetMatchAsync(userId, targetUserId);
            var userProfile = await _profileService.GetProfileAsync(userId);
            var targetProfile = await _profileService.GetProfileAsync(targetUserId);

            if (userProfile == null || targetProfile == null)
                throw new Exception("User or target profile not found");

            var match = existingMatch ?? new Match
            {
                UserId1 = userId,
                UserId2 = targetUserId,
                CompatibilityScore = CalculateCompatibilityScore(userProfile, targetProfile),
                CommonSports = GetCommonSports(userProfile.SportTags, targetProfile.SportTags),
                CommonSchedule = GetCommonScheduleSlots(userProfile.AvailabilitySchedule, targetProfile.AvailabilitySchedule)
            };

            // Set the liker's side (who is liking: userId)
            if (match.UserId1 == userId)
                match.User1Liked = true;
            else
                match.User2Liked = true;
            match.UpdatedAt = DateTime.UtcNow;
            match.IsMatched = match.User1Liked && match.User2Liked;

            await SaveMatchAsync(match);

            var interactionState = match.IsMatched ? UserInteractionState.Matched : UserInteractionState.Sent;
            await UpsertUserInteractionAsync(userId, targetUserId, interactionState);
            if (match.IsMatched)
                await UpsertUserInteractionAsync(targetUserId, userId, UserInteractionState.Matched);

            return new MatchResponse
            {
                MatchId = match.MatchId,
                CompatibilityScore = match.CompatibilityScore,
                IsMatched = match.IsMatched
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error liking user {TargetUserId}", targetUserId);
            throw;
        }
    }

    public async Task<MatchResponse> PassUserAsync(string userId, string targetUserId)
    {
        try
        {
            if (!string.IsNullOrEmpty(targetUserId))
                await RecordDiscoverPassAsync(userId, targetUserId);

            var existingMatch = await GetMatchAsync(userId, targetUserId);
            
            if (existingMatch != null)
            {
                var table = Table.LoadTable(_dynamoDb, _matchesTable);
                await table.DeleteItemAsync(existingMatch.MatchId);
            }

            if (!string.IsNullOrEmpty(targetUserId))
            {
                // Match row is gone; clear the reverse direction so SENT/MATCHED cannot linger for this pair.
                await DeleteUserInteractionAsync(targetUserId, userId);
                await UpsertUserInteractionAsync(userId, targetUserId, UserInteractionState.Skipped);
            }

            return new MatchResponse
            {
                MatchId = "",
                CompatibilityScore = 0,
                IsMatched = false
            };
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error passing user {TargetUserId}", targetUserId);
            throw;
        }
    }

    /// <inheritdoc />
    public async Task CancelSentInviteAsync(string userId, string targetUserId)
    {
        if (string.IsNullOrWhiteSpace(userId) || string.IsNullOrWhiteSpace(targetUserId))
            throw new ArgumentException("User and target are required");
        if (string.Equals(userId, targetUserId, StringComparison.Ordinal))
            throw new InvalidOperationException("Invalid target");

        var state = await GetUserInteractionStateAsync(userId, targetUserId);
        if (state != UserInteractionState.Sent)
        {
            if (state == UserInteractionState.Matched)
                throw new InvalidOperationException("Cannot cancel a mutual match");
            throw new InvalidOperationException("No pending invite to cancel");
        }

        var match = await GetMatchAsync(userId, targetUserId);
        if (match == null)
            throw new InvalidOperationException("Match record not found");

        if (match.IsMatched)
            throw new InvalidOperationException("Cannot cancel a mutual match");

        var iLiked = match.UserId1 == userId ? match.User1Liked : match.User2Liked;
        if (!iLiked)
            throw new InvalidOperationException("No outgoing invite to cancel");

        ClearInteractionSyncThrottle(userId);

        var matchTable = Table.LoadTable(_dynamoDb, _matchesTable);
        await matchTable.DeleteItemAsync(match.MatchId);

        await UpsertUserInteractionAsync(userId, targetUserId, UserInteractionState.Cancelled);

        try
        {
            await DeleteUserInteractionAsync(targetUserId, userId);
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "Cancel invite: optional reverse interaction delete for {Target}->{User}", targetUserId, userId);
        }
    }

    private async Task RecordDiscoverPassAsync(string userId, string targetUserId)
    {
        try
        {
            var table = Table.LoadTable(_dynamoDb, _discoverPassesTable);
            var doc = new Document
            {
                ["userId"] = userId,
                ["targetUserId"] = targetUserId,
                ["createdAt"] = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture),
                ["updatedAt"] = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture),
                ["isSkipped"] = true,
                ["skippedAt"] = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture),
                ["skippedByUserId"] = userId,
                ["restored"] = false,
                ["status"] = "skipped"
            };
            await table.PutItemAsync(doc);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Failed to record discover pass for {TargetUserId}", targetUserId);
            throw;
        }
    }

    private async Task<HashSet<string>> GetPassedTargetUserIdsAsync(string userId)
    {
        await EnsureLegacyInteractionsSyncedForUserAsync(userId);
        var result = new HashSet<string>(StringComparer.Ordinal);
        Dictionary<string, AttributeValue>? startKey = null;
        do
        {
            var query = new QueryRequest
            {
                TableName = _userInteractionsTable,
                KeyConditionExpression = "userId = :u",
                FilterExpression = "#st = :skipped",
                ExpressionAttributeNames = new Dictionary<string, string> { ["#st"] = "state" },
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                {
                    [":u"] = new AttributeValue { S = userId },
                    [":skipped"] = new AttributeValue { S = UserInteractionState.Skipped }
                },
                ExclusiveStartKey = startKey
            };
            var response = await _dynamoDb.QueryAsync(query);
            foreach (var item in response.Items)
            {
                if (!item.TryGetValue("targetUserId", out var tid) || tid.S == null)
                    continue;
                result.Add(tid.S);
            }
            startKey = response.LastEvaluatedKey is { Count: > 0 } ? response.LastEvaluatedKey : null;
        } while (startKey != null);

        return result;
    }

    public async Task<bool> UndoPassAsync(string userId, string targetUserId)
    {
        var viewer = await _profileService.GetProfileAsync(userId);
        if (viewer != null && !viewer.DiscoverCanRewindLastSkip)
            return false;

        var table = Table.LoadTable(_dynamoDb, _discoverPassesTable);
        var document = await table.GetItemAsync(userId, targetUserId);
        if (document == null) return false;

        document["restored"] = true;
        document["isSkipped"] = false;
        document["status"] = "active";
        document["restoredAt"] = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture);
        document["updatedAt"] = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture);
        await table.PutItemAsync(document);
        try
        {
            await DeleteUserInteractionAsync(userId, targetUserId);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Undo pass: could not delete user-interaction row for {UserId}->{Target}", userId, targetUserId);
        }
        return true;
    }

    public async Task<DiscoverSkipRecord?> GetLastSkippedProfileAsync(string userId)
    {
        await EnsureLegacyInteractionsSyncedForUserAsync(userId);
        DiscoverSkipRecord? latestRecord = null;
        Dictionary<string, AttributeValue>? startKey = null;
        do
        {
            var query = new QueryRequest
            {
                TableName = _userInteractionsTable,
                KeyConditionExpression = "userId = :u",
                FilterExpression = "#st = :skipped",
                ExpressionAttributeNames = new Dictionary<string, string> { ["#st"] = "state" },
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                {
                    [":u"] = new AttributeValue { S = userId },
                    [":skipped"] = new AttributeValue { S = UserInteractionState.Skipped }
                },
                ExclusiveStartKey = startKey
            };
            var response = await _dynamoDb.QueryAsync(query);
            foreach (var item in response.Items)
            {
                if (!item.TryGetValue("targetUserId", out var tid) || string.IsNullOrWhiteSpace(tid.S))
                    continue;
                var skippedAt = DateTime.UtcNow;
                if (item.TryGetValue("updatedAt", out var uAt) && DateTime.TryParse(uAt.S, out var parsed))
                    skippedAt = parsed;

                if (latestRecord == null || skippedAt > latestRecord.SkippedAt)
                {
                    latestRecord = new DiscoverSkipRecord
                    {
                        TargetUserId = tid.S!,
                        SkippedAt = skippedAt,
                        SkippedByUserId = userId,
                        IsSkipped = true,
                        Restored = false
                    };
                }
            }
            startKey = response.LastEvaluatedKey is { Count: > 0 } ? response.LastEvaluatedKey : null;
        } while (startKey != null);

        return latestRecord;
    }

    private async Task<Dictionary<string, string>> GetAdminProfileStatusMapAsync()
    {
        var map = new Dictionary<string, string>(StringComparer.Ordinal);
        Dictionary<string, AttributeValue>? startKey = null;
        do
        {
            var query = new QueryRequest
            {
                TableName = _discoverPassesTable,
                KeyConditionExpression = "userId = :u",
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                {
                    [":u"] = new AttributeValue { S = AdminProfileStatusPartitionKey }
                },
                ExclusiveStartKey = startKey
            };
            var response = await _dynamoDb.QueryAsync(query);
            foreach (var item in response.Items)
            {
                if (!item.TryGetValue("targetUserId", out var tid) || string.IsNullOrWhiteSpace(tid.S))
                    continue;
                var value = item.TryGetValue("status", out var statusVal) && !string.IsNullOrWhiteSpace(statusVal.S)
                    ? statusVal.S!
                    : "active";
                map[tid.S!] = value;
            }
            startKey = response.LastEvaluatedKey is { Count: > 0 } ? response.LastEvaluatedKey : null;
        } while (startKey != null);
        return map;
    }

    public async Task<AdminDiscoverControls> GetAdminDiscoverControlsAsync()
    {
        var table = Table.LoadTable(_dynamoDb, _discoverPassesTable);
        var doc = await table.GetItemAsync(AdminControlsPartitionKey, AdminControlsSortKey);
        return new AdminDiscoverControls
        {
            IgnoreSkippedProfilesInDiscoverForAdmin =
                doc != null &&
                doc.ContainsKey("ignoreSkippedProfilesInDiscoverForAdmin") &&
                doc["ignoreSkippedProfilesInDiscoverForAdmin"].AsBoolean()
        };
    }

    public async Task<AdminDiscoverControls> SetAdminDiscoverControlsAsync(bool ignoreSkippedProfilesInDiscoverForAdmin)
    {
        var table = Table.LoadTable(_dynamoDb, _discoverPassesTable);
        var doc = new Document
        {
            ["userId"] = AdminControlsPartitionKey,
            ["targetUserId"] = AdminControlsSortKey,
            ["ignoreSkippedProfilesInDiscoverForAdmin"] = ignoreSkippedProfilesInDiscoverForAdmin,
            ["updatedAt"] = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture),
            ["status"] = "controls"
        };
        await table.PutItemAsync(doc);
        return new AdminDiscoverControls
        {
            IgnoreSkippedProfilesInDiscoverForAdmin = ignoreSkippedProfilesInDiscoverForAdmin
        };
    }

    public async Task<List<AdminDiscoverProfileRow>> ListAdminDiscoverProfilesAsync(string filter = "all", int limit = 200)
    {
        var table = Table.LoadTable(_dynamoDb, _profilesTable);
        var search = table.Scan(new ScanFilter());
        var docs = new List<Document>();
        do
        {
            docs.AddRange(await search.GetNextSetAsync());
        } while (!search.IsDone);

        var matchedProfileIds = await GetMatchedProfileIdsAsync();
        var statusMap = await GetAdminProfileStatusMetadataMapAsync();
        var passSkipsByTarget = await GetLatestDiscoverPassSkipByTargetAsync();

        var rows = docs
            .Where(d => d.ContainsKey("userId"))
            .Select(d =>
            {
                var userId = d["userId"].AsString();
                var explicitStatus = statusMap.TryGetValue(userId, out var m) ? m.Status : null;
                var status = explicitStatus
                    ?? (matchedProfileIds.Contains(userId) ? "matched" : "active");
                DateTime? lastSkipAt = statusMap.TryGetValue(userId, out var sm) ? sm.LastSkippedAt : null;
                string? lastSkipBy = statusMap.TryGetValue(userId, out var sm2) ? sm2.LastSkippedByUserId : null;
                if (passSkipsByTarget.TryGetValue(userId, out var pass) && pass.At.HasValue)
                {
                    if (!lastSkipAt.HasValue || pass.At > lastSkipAt)
                    {
                        lastSkipAt = pass.At;
                        lastSkipBy = pass.By;
                    }
                }

                return new AdminDiscoverProfileRow
                {
                    UserId = userId,
                    Name = d.ContainsKey("name") ? d["name"].AsString() : userId,
                    Status = status,
                    LastSkippedAt = lastSkipAt,
                    LastSkippedByUserId = lastSkipBy
                };
            })
            .ToList();

        if (!string.Equals(filter, "all", StringComparison.OrdinalIgnoreCase))
            rows = rows.Where(r => string.Equals(r.Status, filter, StringComparison.OrdinalIgnoreCase)).ToList();

        var limited = rows
            .OrderByDescending(r => r.LastSkippedAt ?? DateTime.MinValue)
            .ThenBy(r => r.Name)
            .Take(Math.Clamp(limit, 1, 500))
            .ToList();

        var skipperNameMap = await ResolveProfileNamesForUserIdsAsync(
            limited.Select(r => r.LastSkippedByUserId));
        foreach (var r in limited)
        {
            var skipperId = r.LastSkippedByUserId?.Trim();
            if (!string.IsNullOrEmpty(skipperId) &&
                skipperNameMap.TryGetValue(skipperId, out var skipperName))
                r.LastSkippedByName = skipperName;
        }

        return limited;
    }

    private async Task<IReadOnlyDictionary<string, string>> ResolveProfileNamesForUserIdsAsync(
        IEnumerable<string?> userIds,
        CancellationToken cancellationToken = default)
    {
        var distinct = userIds
            .Where(id => !string.IsNullOrWhiteSpace(id))
            .Select(id => id!.Trim())
            .Distinct(StringComparer.Ordinal)
            .ToList();
        if (distinct.Count == 0)
            return new Dictionary<string, string>(StringComparer.Ordinal);

        var tasks = distinct.Select(async id =>
        {
            cancellationToken.ThrowIfCancellationRequested();
            try
            {
                var p = await _profileService.GetProfileAsync(id);
                var label = !string.IsNullOrWhiteSpace(p?.Name) ? p!.Name.Trim() : null;
                return (id, label);
            }
            catch (Exception ex)
            {
                _logger.LogDebug(ex, "Resolve profile name for userId {UserId}", id);
                return (id, (string?)null);
            }
        });

        var pairs = await Task.WhenAll(tasks);
        var map = new Dictionary<string, string>(StringComparer.Ordinal);
        foreach (var (id, label) in pairs)
        {
            if (!string.IsNullOrEmpty(label))
                map[id] = label!;
        }

        return map;
    }

    public async Task<bool> AdminSetProfileDiscoverStatusAsync(string profileUserId, string status, string adminUserId)
    {
        var normalized = status.Trim().ToLowerInvariant();
        if (normalized is not ("active" or "skipped" or "hidden" or "matched"))
            return false;

        var table = Table.LoadTable(_dynamoDb, _discoverPassesTable);
        var doc = new Document
        {
            ["userId"] = AdminProfileStatusPartitionKey,
            ["targetUserId"] = profileUserId,
            ["status"] = normalized,
            ["updatedAt"] = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture),
            ["updatedByUserId"] = adminUserId
        };
        if (normalized == "skipped")
        {
            doc["skippedAt"] = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture);
            doc["skippedByUserId"] = adminUserId;
            doc["isSkipped"] = true;
        }
        if (normalized == "active")
        {
            doc["isSkipped"] = false;
            doc["restored"] = true;
        }
        await table.PutItemAsync(doc);
        return true;
    }

    public async Task<bool> AdminResetProfileInteractionStateAsync(string profileUserId)
    {
        var scan = await _dynamoDb.ScanAsync(new ScanRequest
        {
            TableName = _discoverPassesTable,
            FilterExpression = "targetUserId = :t and userId <> :controls and userId <> :statusPk",
            ExpressionAttributeValues = new Dictionary<string, AttributeValue>
            {
                [":t"] = new AttributeValue { S = profileUserId },
                [":controls"] = new AttributeValue { S = AdminControlsPartitionKey },
                [":statusPk"] = new AttributeValue { S = AdminProfileStatusPartitionKey }
            }
        });

        foreach (var item in scan.Items)
        {
            if (!item.TryGetValue("userId", out var uid) || uid.S == null) continue;
            if (!item.TryGetValue("targetUserId", out var tid) || tid.S == null) continue;
            await _dynamoDb.DeleteItemAsync(new DeleteItemRequest
            {
                TableName = _discoverPassesTable,
                Key = new Dictionary<string, AttributeValue>
                {
                    ["userId"] = new AttributeValue { S = uid.S },
                    ["targetUserId"] = new AttributeValue { S = tid.S }
                }
            });
        }

        var uiScan = await _dynamoDb.ScanAsync(new ScanRequest
        {
            TableName = _userInteractionsTable,
            FilterExpression = "targetUserId = :t",
            ExpressionAttributeValues = new Dictionary<string, AttributeValue>
            {
                [":t"] = new AttributeValue { S = profileUserId }
            }
        });
        foreach (var item in uiScan.Items)
        {
            if (!item.TryGetValue("userId", out var uid) || uid.S == null) continue;
            if (!item.TryGetValue("targetUserId", out var tid) || tid.S == null) continue;
            await _dynamoDb.DeleteItemAsync(new DeleteItemRequest
            {
                TableName = _userInteractionsTable,
                Key = new Dictionary<string, AttributeValue>
                {
                    ["userId"] = new AttributeValue { S = uid.S },
                    ["targetUserId"] = new AttributeValue { S = tid.S }
                }
            });
        }

        return true;
    }

    private async Task<HashSet<string>> GetMatchedProfileIdsAsync()
    {
        var table = Table.LoadTable(_dynamoDb, _matchesTable);
        var scan = table.Scan(new ScanFilter());
        var ids = new HashSet<string>(StringComparer.Ordinal);
        do
        {
            var batch = await scan.GetNextSetAsync();
            foreach (var doc in batch)
            {
                if (!doc.ContainsKey("isMatched") || !doc["isMatched"].AsBoolean()) continue;
                if (doc.ContainsKey("userId1")) ids.Add(doc["userId1"].AsString());
                if (doc.ContainsKey("userId2")) ids.Add(doc["userId2"].AsString());
            }
        } while (!scan.IsDone);
        return ids;
    }

    /// <summary>
    /// Latest in-app Discover pass per <b>target</b> profile (viewer → target rows in discover-passes), excluding admin partition keys.
    /// </summary>
    private async Task<Dictionary<string, (DateTime? At, string? By)>> GetLatestDiscoverPassSkipByTargetAsync()
    {
        var map = new Dictionary<string, (DateTime? At, string? By)>(StringComparer.Ordinal);
        try
        {
            var table = Table.LoadTable(_dynamoDb, _discoverPassesTable);
            var scan = table.Scan(new ScanFilter());
            do
            {
                foreach (var doc in await scan.GetNextSetAsync())
                {
                    if (!doc.ContainsKey("userId") || !doc.ContainsKey("targetUserId")) continue;
                    var pk = doc["userId"].AsString();
                    if (pk == AdminControlsPartitionKey || pk == AdminProfileStatusPartitionKey) continue;
                    var tid = doc["targetUserId"].AsString();
                    if (string.IsNullOrEmpty(tid)) continue;
                    if (!doc.ContainsKey("skippedAt")) continue;
                    if (!DateTime.TryParse(doc["skippedAt"].AsString(), CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var at))
                        continue;
                    var by = doc.ContainsKey("skippedByUserId") ? doc["skippedByUserId"].AsString() : pk;
                    if (string.IsNullOrEmpty(by)) by = pk;
                    if (!map.TryGetValue(tid, out var cur) || !cur.At.HasValue || at > cur.At.Value)
                        map[tid] = (at, by);
                }
            } while (!scan.IsDone);
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "GetLatestDiscoverPassSkipByTargetAsync failed");
        }

        return map;
    }

    private async Task<Dictionary<string, (string Status, DateTime? LastSkippedAt, string? LastSkippedByUserId)>> GetAdminProfileStatusMetadataMapAsync()
    {
        var map = new Dictionary<string, (string, DateTime?, string?)>(StringComparer.Ordinal);
        Dictionary<string, AttributeValue>? startKey = null;
        do
        {
            var query = new QueryRequest
            {
                TableName = _discoverPassesTable,
                KeyConditionExpression = "userId = :u",
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                {
                    [":u"] = new AttributeValue { S = AdminProfileStatusPartitionKey }
                },
                ExclusiveStartKey = startKey
            };
            var response = await _dynamoDb.QueryAsync(query);
            foreach (var item in response.Items)
            {
                if (!item.TryGetValue("targetUserId", out var tid) || string.IsNullOrWhiteSpace(tid.S))
                    continue;
                var key = tid.S!;
                var status = item.TryGetValue("status", out var statusVal) && !string.IsNullOrWhiteSpace(statusVal.S)
                    ? statusVal.S!
                    : "active";
                DateTime? skippedAt = null;
                if (item.TryGetValue("skippedAt", out var skippedVal) && DateTime.TryParse(skippedVal.S, out var dt))
                    skippedAt = dt;
                var skippedBy = item.TryGetValue("skippedByUserId", out var skippedByVal) ? skippedByVal.S : null;
                map[key] = (status, skippedAt, skippedBy);
            }
            startKey = response.LastEvaluatedKey is { Count: > 0 } ? response.LastEvaluatedKey : null;
        } while (startKey != null);
        return map;
    }

    /// <summary>
    /// Mutual matches only: both sides liked (<see cref="Match.IsMatched"/>).
    /// Scans the full table then filters in memory so we never depend on incorrect ScanFilter attribute casing
    /// (Dynamo stores <c>isMatched</c>, not <c>IsMatched</c> — a bad filter previously returned zero rows).
    /// </summary>
    public async Task<List<Match>> GetUserMatchesAsync(string userId)
    {
        try
        {
            await EnsureLegacyInteractionsSyncedForUserAsync(userId);
            var rows = new List<(string TargetId, DateTime UpdatedAt)>();
            Dictionary<string, AttributeValue>? startKey = null;
            do
            {
                var query = new QueryRequest
                {
                    TableName = _userInteractionsTable,
                    KeyConditionExpression = "userId = :u",
                    FilterExpression = "#st = :matched",
                    ExpressionAttributeNames = new Dictionary<string, string> { ["#st"] = "state" },
                    ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                    {
                        [":u"] = new AttributeValue { S = userId },
                        [":matched"] = new AttributeValue { S = UserInteractionState.Matched }
                    },
                    ExclusiveStartKey = startKey
                };
                var response = await _dynamoDb.QueryAsync(query);
                foreach (var item in response.Items)
                {
                    if (!item.TryGetValue("targetUserId", out var tid) || string.IsNullOrWhiteSpace(tid.S))
                        continue;
                    var uAt = DateTime.UtcNow;
                    if (item.TryGetValue("updatedAt", out var u) && DateTime.TryParse(u.S, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var parsed))
                        uAt = parsed.ToUniversalTime();
                    rows.Add((tid.S!, uAt));
                }
                startKey = response.LastEvaluatedKey is { Count: > 0 } ? response.LastEvaluatedKey : null;
            } while (startKey != null);

            var matches = new List<Match>();
            foreach (var (otherId, _) in rows.OrderByDescending(x => x.UpdatedAt))
            {
                var m = await GetMatchAsync(userId, otherId);
                if (m == null || !m.IsMatched)
                {
                    _logger.LogWarning("Matches list: interaction MATCHED for {User}->{Target} but match row missing or not mutual", userId, otherId);
                    continue;
                }
                matches.Add(m);
            }

            return matches;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting matches for user {UserId}", userId);
            throw;
        }
    }

    public async Task<Match?> GetMatchAsync(string userId1, string userId2)
    {
        try
        {
            var table = Table.LoadTable(_dynamoDb, _matchesTable);
            var scanFilter = new ScanFilter();
            
            var search = table.Scan(scanFilter);
            
            do
            {
                var batch = await search.GetNextSetAsync();
                foreach (var doc in batch)
                {
                    var u1 = doc["userId1"].AsString();
                    var u2 = doc["userId2"].AsString();
                    
                    if ((u1 == userId1 && u2 == userId2) || (u1 == userId2 && u2 == userId1))
                    {
                        return DocumentToMatch(doc);
                    }
                }
            } while (!search.IsDone);

            return null;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Error getting match between {UserId1} and {UserId2}", userId1, userId2);
            return null;
        }
    }

    public async Task<Match?> GetMatchByIdAsync(string matchId)
    {
        if (string.IsNullOrEmpty(matchId)) return null;
        try
        {
            var table = Table.LoadTable(_dynamoDb, _matchesTable);
            var keyDoc = new Document { ["matchId"] = matchId };
            var doc = await table.GetItemAsync(keyDoc);
            return doc != null ? DocumentToMatch(doc) : null;
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Error getting match by id {MatchId}", matchId);
            return null;
        }
    }

    /// <summary>All match rows where the user is a participant (single table scan; reuse for sent + discover exclusions).</summary>
    private async Task<List<Match>> ListMatchesInvolvingUserAsync(string userId)
    {
        var table = Table.LoadTable(_dynamoDb, _matchesTable);
        var search = table.Scan(new ScanFilter());
        var list = new List<Match>();
        do
        {
            foreach (var doc in await search.GetNextSetAsync())
            {
                var m = DocumentToMatch(doc);
                if (m.UserId1 == userId || m.UserId2 == userId)
                    list.Add(m);
            }
        } while (!search.IsDone);

        return list;
    }

    public async Task<List<SentRequestItem>> ListSentRequestsAsync(string userId)
    {
        await EnsureLegacyInteractionsSyncedForUserAsync(userId);
        var rows = new List<(string TargetId, string State, DateTime InteractionUpdatedAt)>();
        Dictionary<string, AttributeValue>? startKey = null;
        do
        {
            var query = new QueryRequest
            {
                TableName = _userInteractionsTable,
                KeyConditionExpression = "userId = :u",
                FilterExpression = "(#st = :sent OR #st = :matched)",
                ExpressionAttributeNames = new Dictionary<string, string> { ["#st"] = "state" },
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                {
                    [":u"] = new AttributeValue { S = userId },
                    [":sent"] = new AttributeValue { S = UserInteractionState.Sent },
                    [":matched"] = new AttributeValue { S = UserInteractionState.Matched }
                },
                ExclusiveStartKey = startKey
            };
            var response = await _dynamoDb.QueryAsync(query);
            foreach (var item in response.Items)
            {
                if (!item.TryGetValue("targetUserId", out var tid) || string.IsNullOrWhiteSpace(tid.S))
                    continue;
                var st = item.TryGetValue("state", out var sVal) && sVal.S != null ? sVal.S! : UserInteractionState.Sent;
                var iaUpdated = DateTime.UtcNow;
                if (item.TryGetValue("updatedAt", out var uAt) && DateTime.TryParse(uAt.S, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var parsed))
                    iaUpdated = parsed.ToUniversalTime();
                rows.Add((tid.S!, st, iaUpdated));
            }
            startKey = response.LastEvaluatedKey is { Count: > 0 } ? response.LastEvaluatedKey : null;
        } while (startKey != null);

        var list = new List<SentRequestItem>();
        foreach (var (otherId, st, _) in rows.OrderByDescending(x => x.InteractionUpdatedAt).Take(RelationshipListLimit))
        {
            if (string.Equals(otherId, userId, StringComparison.Ordinal))
                continue;
            var m = await GetMatchAsync(userId, otherId);
            if (m == null)
            {
                _logger.LogWarning("Sent list: interaction {State} for {User}->{Target} but no match row", st, userId, otherId);
                continue;
            }
            var tp = await _profileService.GetProfileAsync(otherId);
            var name = tp?.Name ?? "User";
            var photos = ResolvePhotoUrlsForProfile(tp);
            list.Add(new SentRequestItem
            {
                UserId = otherId,
                Name = name,
                City = tp?.City,
                PhotoUrls = photos,
                Status = st == UserInteractionState.Matched ? "Matched" : "Pending",
                MatchId = m.MatchId,
                CompatibilityScore = m.CompatibilityScore,
                UpdatedAt = m.UpdatedAt
            });
        }

        return list;
    }

    /// <summary>
    /// Lists users who sent interest to <paramref name="viewerUserId"/> (interaction row other→viewer = Sent).
    /// Uses a filtered table scan; consider a GSI on <c>targetUserId</c> at high scale.
    /// </summary>
    public async Task<List<SentRequestItem>> ListIncomingPendingLikesAsync(string viewerUserId)
    {
        if (string.IsNullOrEmpty(viewerUserId))
            return new List<SentRequestItem>();

        await EnsureLegacyInteractionsSyncedForUserAsync(viewerUserId);

        var rows = new List<(string FromUserId, DateTime UpdatedAt)>();
        Dictionary<string, AttributeValue>? scanStartKey = null;
        do
        {
            var request = new ScanRequest
            {
                TableName = _userInteractionsTable,
                FilterExpression = "targetUserId = :me AND #st = :sent",
                ExpressionAttributeNames = new Dictionary<string, string> { ["#st"] = "state" },
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                {
                    [":me"] = new AttributeValue { S = viewerUserId },
                    [":sent"] = new AttributeValue { S = UserInteractionState.Sent }
                },
                ExclusiveStartKey = scanStartKey
            };
            var response = await _dynamoDb.ScanAsync(request);
            foreach (var item in response.Items)
            {
                if (!item.TryGetValue("userId", out var uid) || string.IsNullOrWhiteSpace(uid.S))
                    continue;
                if (string.Equals(uid.S, viewerUserId, StringComparison.Ordinal))
                    continue;
                var iaUpdated = DateTime.UtcNow;
                if (item.TryGetValue("updatedAt", out var uAt) &&
                    DateTime.TryParse(uAt.S, CultureInfo.InvariantCulture, DateTimeStyles.RoundtripKind, out var parsed))
                    iaUpdated = parsed.ToUniversalTime();
                rows.Add((uid.S!, iaUpdated));
            }

            scanStartKey = response.LastEvaluatedKey is { Count: > 0 } ? response.LastEvaluatedKey : null;
        } while (scanStartKey != null);

        var list = new List<SentRequestItem>();
        foreach (var (fromUserId, _) in rows.OrderByDescending(x => x.UpdatedAt).Take(RelationshipListLimit))
        {
            var m = await GetMatchAsync(fromUserId, viewerUserId);
            if (m == null)
            {
                _logger.LogWarning(
                    "Incoming likes: Sent interaction from {From} to {Viewer} but no match row",
                    fromUserId,
                    viewerUserId);
                continue;
            }

            var tp = await _profileService.GetProfileAsync(fromUserId);
            var name = tp?.Name ?? "User";
            var photos = ResolvePhotoUrlsForProfile(tp);
            list.Add(new SentRequestItem
            {
                UserId = fromUserId,
                Name = name,
                City = tp?.City,
                PhotoUrls = photos,
                Status = "Pending",
                MatchId = m.MatchId,
                CompatibilityScore = m.CompatibilityScore,
                UpdatedAt = m.UpdatedAt
            });
        }

        return list;
    }

    public async Task<List<SkippedProfileItem>> ListSkippedProfilesAsync(string userId)
    {
        await EnsureLegacyInteractionsSyncedForUserAsync(userId);
        var rows = new List<(string TargetId, DateTime SkippedAt)>();
        Dictionary<string, AttributeValue>? startKey = null;
        do
        {
            var query = new QueryRequest
            {
                TableName = _userInteractionsTable,
                KeyConditionExpression = "userId = :u",
                FilterExpression = "#st = :skipped",
                ExpressionAttributeNames = new Dictionary<string, string> { ["#st"] = "state" },
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                {
                    [":u"] = new AttributeValue { S = userId },
                    [":skipped"] = new AttributeValue { S = UserInteractionState.Skipped }
                },
                ExclusiveStartKey = startKey
            };
            var response = await _dynamoDb.QueryAsync(query);
            foreach (var item in response.Items)
            {
                if (!item.TryGetValue("targetUserId", out var tid) || string.IsNullOrWhiteSpace(tid.S))
                    continue;
                var skippedAt = DateTime.UtcNow;
                if (item.TryGetValue("updatedAt", out var uAt) && DateTime.TryParse(uAt.S, out var parsed))
                    skippedAt = parsed;

                rows.Add((tid.S!, skippedAt));
            }
            startKey = response.LastEvaluatedKey is { Count: > 0 } ? response.LastEvaluatedKey : null;
        } while (startKey != null);

        var list = new List<SkippedProfileItem>();
        foreach (var (targetId, skippedAt) in rows.OrderByDescending(x => x.SkippedAt))
        {
            if (string.Equals(targetId, userId, StringComparison.Ordinal))
                continue;
            var tp = await _profileService.GetProfileAsync(targetId);
            if (tp == null) continue;
            list.Add(new SkippedProfileItem
            {
                UserId = targetId,
                Name = tp.Name ?? "User",
                City = tp.City,
                PhotoUrls = ResolvePhotoUrlsForProfile(tp),
                SkippedAt = skippedAt
            });
        }
        return list.Take(RelationshipListLimit).ToList();
    }

    private async Task<HashSet<string>> GetUserIdsExcludedFromDiscoverByMatchesAsync(string userId)
    {
        await EnsureLegacyInteractionsSyncedForUserAsync(userId);
        var excluded = new HashSet<string>(StringComparer.Ordinal);
        Dictionary<string, AttributeValue>? startKey = null;
        do
        {
            var query = new QueryRequest
            {
                TableName = _userInteractionsTable,
                KeyConditionExpression = "userId = :u",
                FilterExpression = "(#st = :sent OR #st = :matched OR #st = :cancelled)",
                ExpressionAttributeNames = new Dictionary<string, string> { ["#st"] = "state" },
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                {
                    [":u"] = new AttributeValue { S = userId },
                    [":sent"] = new AttributeValue { S = UserInteractionState.Sent },
                    [":matched"] = new AttributeValue { S = UserInteractionState.Matched },
                    [":cancelled"] = new AttributeValue { S = UserInteractionState.Cancelled }
                },
                ExclusiveStartKey = startKey
            };
            var response = await _dynamoDb.QueryAsync(query);
            foreach (var item in response.Items)
            {
                if (!item.TryGetValue("targetUserId", out var tid) || string.IsNullOrWhiteSpace(tid.S))
                    continue;
                excluded.Add(tid.S!);
            }
            startKey = response.LastEvaluatedKey is { Count: > 0 } ? response.LastEvaluatedKey : null;
        } while (startKey != null);

        return excluded;
    }

    private List<string> ResolvePhotoUrlsForProfile(UserProfile? targetProfile)
    {
        if (targetProfile == null) return new List<string>();
        var raw = targetProfile.PhotoUrls ?? new List<string>();
        var list = raw.Where(u => !string.IsNullOrWhiteSpace(u)).Select(u => u.Trim()).ToList();
        for (var i = 0; i < list.Count; i++)
        {
            var signed = _storageService.TryPresignCanonicalMediaUrl(list[i], TimeSpan.FromHours(1));
            if (!string.IsNullOrEmpty(signed))
                list[i] = signed!;
        }
        if (list.Count > 0) return list;
        var keyForCover = targetProfile.PhotoKeys != null && targetProfile.PhotoKeys.Count > 0
            ? targetProfile.PhotoKeys[0]
            : targetProfile.PhotoKey;
        if (string.IsNullOrEmpty(keyForCover)) return list;
        try
        {
            var signedUrl = _storageService.GetPresignedDownloadUrl(keyForCover, TimeSpan.FromHours(1));
            return new List<string> { signedUrl };
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Could not presign photo for user {UserId}", targetProfile.UserId);
            return list;
        }
    }

    private int CalculateCompatibilityScore(UserProfile user1, UserProfile user2)
    {
        int score = 0;

        // Sports match (30 points max)
        var commonSports = GetCommonSports(user1.SportTags, user2.SportTags).Count;
        var totalSports = new HashSet<string>(user1.SportTags.Concat(user2.SportTags)).Count;
        score += (int)(commonSports > 0 ? (commonSports / (double)totalSports) * SportsMatchWeight : 0);

        // Schedule match (25 points max)
        var commonSchedule = GetCommonScheduleSlots(user1.AvailabilitySchedule, user2.AvailabilitySchedule).Count;
        score += Math.Min(commonSchedule * 2, ScheduleMatchWeight); // 2 points per common slot, max 25

        // Level compatibility (20 points max)
        if (user1.Level == user2.Level)
            score += LevelMatchWeight;
        else if (LevelsCompatible(user1.Level, user2.Level))
            score += LevelMatchWeight - 5;

        // Distance penalty (15 points max)
        var distance = CalculateDistance(user1.Latitude, user1.Longitude, user2.Latitude, user2.Longitude);
        if (distance < 5) score += DistanceWeight;
        else if (distance < 15) score += DistanceWeight - 5;
        else if (distance < 30) score += DistanceWeight - 10;

        score += GetIntentModePoints(user1, user2);

        return Math.Min(score, 100);
    }

    private int GetIntentModePoints(UserProfile user1, UserProfile user2)
    {
        if (!ProfileModes.HasIntentOverlap(user1, user2))
            return 0;
        if (ProfileModes.IsExactIntentAlignment(user1, user2))
            return ModeMatchWeight;
        return Math.Max(0, ModeMatchWeight - 4);
    }

    private (List<string> Preview, List<string> Locked) BuildMatchInsightReasons(
        UserProfile viewer, UserProfile target, double distanceKm)
    {
        var preview = new List<string>();
        if (ProfileModes.HasIntentOverlap(viewer, target))
        {
            if (ProfileModes.IsExactIntentAlignment(viewer, target))
                preview.Add("✔ Same intent");
            else
                preview.Add("✔ Shared intent");
        }

        if (!string.IsNullOrEmpty(viewer.Level) && !string.IsNullOrEmpty(target.Level))
        {
            if (string.Equals(viewer.Level, target.Level, StringComparison.OrdinalIgnoreCase))
                preview.Add("✔ Same intensity");
            else if (LevelsCompatible(viewer.Level, target.Level))
                preview.Add("✔ Similar level");
        }

        if (distanceKm < 400)
        {
            if (distanceKm < 15)
                preview.Add("✔ Close by");
            else
                preview.Add("✔ Location match");
        }

        var commonGoals = viewer.Goals.Intersect(target.Goals, StringComparer.OrdinalIgnoreCase).ToList();
        if (commonGoals.Count > 0)
            preview.Add("✔ Similar goals");

        var locked = new List<string>
        {
            "🔒 Strength compatibility",
            "🔒 Training rhythm",
            "🔒 Personality fit"
        };

        return (preview.Take(3).ToList(), locked);
    }

    private List<string> GetCommonSports(List<string> sports1, List<string> sports2)
    {
        return sports1.Intersect(sports2, StringComparer.OrdinalIgnoreCase).ToList();
    }

    private List<string> GetCommonSchedule(List<string> schedule1, List<string> schedule2)
    {
        return schedule1.Intersect(schedule2, StringComparer.OrdinalIgnoreCase).ToList();
    }

    private List<string> GetCommonScheduleSlots(List<AvailabilitySlot> schedule1, List<AvailabilitySlot> schedule2)
    {
        // Compare availability slots by days and time windows
        var common = new List<string>();
        foreach (var slot1 in schedule1)
        {
            foreach (var slot2 in schedule2)
            {
                // Check if days overlap
                var commonDays = slot1.Days.Intersect(slot2.Days, StringComparer.OrdinalIgnoreCase).ToList();
                if (commonDays.Any())
                {
                    // Check if time windows overlap
                    if (TimeWindowsOverlap(slot1.TimeStart, slot1.TimeEnd, slot2.TimeStart, slot2.TimeEnd))
                    {
                        common.Add($"{string.Join(",", commonDays)}: {slot1.TimeStart}-{slot1.TimeEnd}");
                    }
                }
            }
        }
        return common;
    }

    private bool TimeWindowsOverlap(string start1, string end1, string start2, string end2)
    {
        // Simple time overlap check (24-hour format "HH:mm")
        try
        {
            var time1Start = TimeSpan.Parse(start1);
            var time1End = TimeSpan.Parse(end1);
            var time2Start = TimeSpan.Parse(start2);
            var time2End = TimeSpan.Parse(end2);

            // Handle wrap-around (e.g., 21:00 to 00:00)
            if (time1End < time1Start) time1End = time1End.Add(TimeSpan.FromDays(1));
            if (time2End < time2Start) time2End = time2End.Add(TimeSpan.FromDays(1));

            return time1Start < time2End && time2Start < time1End;
        }
        catch
        {
            return false;
        }
    }

    private static bool LevelsCompatible(string? level1, string? level2)
    {
        if (string.IsNullOrEmpty(level1) || string.IsNullOrEmpty(level2))
            return true;

        var levels = new[] { "beginner", "intermediate", "advanced", "pro" };
        var idx1 = Array.IndexOf(levels, level1.ToLower());
        var idx2 = Array.IndexOf(levels, level2.ToLower());

        return Math.Abs(idx1 - idx2) <= 1;
    }

    private double CalculateDistance(double? lat1, double? lon1, double? lat2, double? lon2)
    {
        if (!lat1.HasValue || !lon1.HasValue || !lat2.HasValue || !lon2.HasValue)
            return double.MaxValue;

        const double R = 6371; // Earth radius in km
        var dLat = ToRad(lat2.Value - lat1.Value);
        var dLon = ToRad(lon2.Value - lon1.Value);
        var a = Math.Sin(dLat / 2) * Math.Sin(dLat / 2) +
                Math.Cos(ToRad(lat1.Value)) * Math.Cos(ToRad(lat2.Value)) *
                Math.Sin(dLon / 2) * Math.Sin(dLon / 2);
        var c = 2 * Math.Atan2(Math.Sqrt(a), Math.Sqrt(1 - a));
        return R * c;
    }

    private double ToRad(double deg) => deg * (Math.PI / 180);

    private async Task SaveMatchAsync(Match match)
    {
        var table = Table.LoadTable(_dynamoDb, _matchesTable);
        var doc = MatchToDocument(match);
        await table.PutItemAsync(doc);
    }

    private Document MatchToDocument(Match match)
    {
        var doc = new Document
        {
            ["matchId"] = match.MatchId,
            ["userId1"] = match.UserId1,
            ["userId2"] = match.UserId2,
            ["compatibilityScore"] = match.CompatibilityScore,
            ["user1Liked"] = match.User1Liked,
            ["user2Liked"] = match.User2Liked,
            ["isMatched"] = match.IsMatched,
            ["distance"] = match.Distance,
            ["createdAt"] = match.CreatedAt.ToString("O"),
            ["updatedAt"] = match.UpdatedAt.ToString("O")
        };

        if (match.CommonSports.Any())
            doc["commonSports"] = new DynamoDBList(match.CommonSports.Select(s => new Primitive(s)));
        if (match.CommonSchedule.Any())
            doc["commonSchedule"] = new DynamoDBList(match.CommonSchedule.Select(s => new Primitive(s)));

        return doc;
    }

    private Match DocumentToMatch(Document doc)
    {
        return new Match
        {
            MatchId = doc["matchId"],
            UserId1 = doc["userId1"],
            UserId2 = doc["userId2"],
            CompatibilityScore = (int)doc["compatibilityScore"].AsInt(),
            User1Liked = doc["user1Liked"].AsBoolean(),
            User2Liked = doc["user2Liked"].AsBoolean(),
            IsMatched = doc["isMatched"].AsBoolean(),
            Distance = doc.ContainsKey("distance") ? doc["distance"].AsDouble() : 0,
            CommonSports = doc.ContainsKey("commonSports") ? doc["commonSports"].AsListOfString() : new List<string>(),
            CommonSchedule = doc.ContainsKey("commonSchedule") ? doc["commonSchedule"].AsListOfString() : new List<string>(),
            CreatedAt = DateTime.Parse(doc["createdAt"]),
            UpdatedAt = DateTime.Parse(doc["updatedAt"])
        };
    }

    private UserProfile DocumentToProfile(Document document)
    {
        var userId = document.ContainsKey("userId") ? document["userId"].AsString() : string.Empty;
        var email = document.ContainsKey("email") ? document["email"].AsString() : string.Empty;
        var name = document.ContainsKey("name") ? document["name"].AsString() : string.Empty;
        var mode = document.ContainsKey("mode") ? document["mode"].AsString() : "TRAIN";
        var isComplete = document.ContainsKey("isComplete") ? document["isComplete"].AsBoolean() : false;
        var createdAt = document.ContainsKey("createdAt") && DateTime.TryParse(document["createdAt"].AsString(), out var ca) ? ca : DateTime.UtcNow;
        var updatedAt = document.ContainsKey("updatedAt") && DateTime.TryParse(document["updatedAt"].AsString(), out var ua) ? ua : DateTime.UtcNow;

        var photoKey = document.ContainsKey("photoKey") ? document["photoKey"].AsString() : null;
        var photoKeys = document.ContainsKey("photoKeys") ? document["photoKeys"].AsListOfString() : new List<string>();
        if (photoKeys.Count == 0 && !string.IsNullOrEmpty(photoKey))
            photoKeys = new List<string> { photoKey };

        var modes = document.ContainsKey("modes") && document["modes"] is DynamoDBList modesList
            ? modesList.AsListOfString().Select(ProfileModes.Normalize).Distinct().ToList()
            : new List<string>();

        var profile = new UserProfile
        {
            UserId = userId,
            Email = email,
            Name = name,
            City = document.ContainsKey("city") ? document["city"].AsString() : null,
            Bio = document.ContainsKey("bio") ? document["bio"].AsString() : null,
            SportTags = document.ContainsKey("sportTags") ? document["sportTags"].AsListOfString() : new List<string>(),
            Level = document.ContainsKey("level") ? document["level"].AsString() : null,
            PhotoKey = photoKey,
            PhotoKeys = photoKeys,
            Goals = document.ContainsKey("goals") ?
                (document["goals"] is DynamoDBList goalsList ? goalsList.AsListOfString() :
                 document["goals"].AsString() is string goalsStr && !string.IsNullOrEmpty(goalsStr) ? new List<string> { goalsStr } :
                 new List<string>()) : new List<string>(),
            AvailabilitySchedule = new List<AvailabilitySlot>(),
            Mode = mode,
            Modes = modes,
            WorkoutStyle = document.ContainsKey("workoutStyle") ? document["workoutStyle"].AsString() : null,
            PersonalityTag = document.ContainsKey("personalityTag") ? document["personalityTag"].AsString() : null,
            Latitude = document.ContainsKey("latitude") ? (double?)document["latitude"].AsDouble() : null,
            Longitude = document.ContainsKey("longitude") ? (double?)document["longitude"].AsDouble() : null,
            PhotoUrls = document.ContainsKey("photoUrls") ? document["photoUrls"].AsListOfString() : new List<string>(),
            IsComplete = isComplete,
            CreatedAt = createdAt,
            UpdatedAt = updatedAt
        };

        if (document.ContainsKey("availabilitySchedule"))
        {
            try
            {
                var availabilityEntry = document["availabilitySchedule"];
                if (availabilityEntry is Primitive primitive && primitive.Type == DynamoDBEntryType.String)
                {
                    var availabilityStr = primitive.AsString();
                    if (!string.IsNullOrEmpty(availabilityStr) && availabilityStr.StartsWith("["))
                        profile.AvailabilitySchedule = JsonSerializer.Deserialize<List<AvailabilitySlot>>(availabilityStr) ?? new List<AvailabilitySlot>();
                }
            }
            catch
            {
                profile.AvailabilitySchedule = new List<AvailabilitySlot>();
            }
        }

        if (profile.Modes.Count == 0)
            profile.Modes = new List<string> { ProfileModes.Normalize(profile.Mode) };
        else
            profile.Mode = profile.Modes[0];

        return profile;
    }

    private async Task UpsertUserInteractionAsync(string userId, string targetUserId, string state)
    {
        if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(targetUserId)) return;
        if (string.Equals(userId, targetUserId, StringComparison.Ordinal)) return;
        var table = Table.LoadTable(_dynamoDb, _userInteractionsTable);
        var doc = new Document
        {
            ["userId"] = userId,
            ["targetUserId"] = targetUserId,
            ["state"] = state,
            ["updatedAt"] = DateTime.UtcNow.ToString("O", CultureInfo.InvariantCulture)
        };
        await table.PutItemAsync(doc);
    }

    private async Task DeleteUserInteractionAsync(string userId, string targetUserId)
    {
        if (string.IsNullOrEmpty(userId) || string.IsNullOrEmpty(targetUserId)) return;
        var table = Table.LoadTable(_dynamoDb, _userInteractionsTable);
        await table.DeleteItemAsync(userId, targetUserId);
    }

    private async Task<string?> GetUserInteractionStateAsync(string userId, string targetUserId)
    {
        try
        {
            var table = Table.LoadTable(_dynamoDb, _userInteractionsTable);
            var doc = await table.GetItemAsync(userId, targetUserId);
            if (doc == null || !doc.ContainsKey("state")) return null;
            return doc["state"].AsString();
        }
        catch (Exception ex)
        {
            _logger.LogDebug(ex, "GetUserInteractionState failed for {User}->{Target}", userId, targetUserId);
            return null;
        }
    }

    private async Task EnsureLegacyInteractionsSyncedForUserAsync(string userId)
    {
        if (string.IsNullOrEmpty(userId) || userId.StartsWith("__", StringComparison.Ordinal)) return;
        var nowMs = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
        // Full match scan per user is expensive; throttle to avoid one scan per discover request.
        if (LastUserInteractionSyncMs.TryGetValue(userId, out var last) && nowMs - last < 300_000)
            return;
        LastUserInteractionSyncMs[userId] = nowMs;

        foreach (var m in await ListMatchesInvolvingUserAsync(userId))
        {
            var other = m.UserId1 == userId ? m.UserId2 : m.UserId1;
            var iLiked = m.UserId1 == userId ? m.User1Liked : m.User2Liked;
            if (!iLiked) continue;
            var state = m.IsMatched ? UserInteractionState.Matched : UserInteractionState.Sent;
            await UpsertUserInteractionAsync(userId, other, state);
        }

        Dictionary<string, AttributeValue>? startKey = null;
        do
        {
            var query = new QueryRequest
            {
                TableName = _discoverPassesTable,
                KeyConditionExpression = "userId = :u",
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                {
                    [":u"] = new AttributeValue { S = userId }
                },
                ExclusiveStartKey = startKey
            };
            var response = await _dynamoDb.QueryAsync(query);
            foreach (var item in response.Items)
            {
                if (!item.TryGetValue("targetUserId", out var tid) || string.IsNullOrWhiteSpace(tid.S))
                    continue;
                var target = tid.S!;
                if (string.Equals(target, userId, StringComparison.Ordinal)) continue;

                var isSkipped = !item.TryGetValue("isSkipped", out var skippedVal) || skippedVal.BOOL;
                var restored = item.TryGetValue("restored", out var restoredVal) && restoredVal.BOOL;
                var status = item.TryGetValue("status", out var statusVal) ? statusVal.S : "skipped";
                if (!isSkipped || restored || string.Equals(status, "active", StringComparison.OrdinalIgnoreCase))
                    continue;

                var existing = await GetUserInteractionStateAsync(userId, target);
                if (existing == UserInteractionState.Sent || existing == UserInteractionState.Matched || existing == UserInteractionState.Cancelled)
                    continue;

                await UpsertUserInteractionAsync(userId, target, UserInteractionState.Skipped);
            }
            startKey = response.LastEvaluatedKey is { Count: > 0 } ? response.LastEvaluatedKey : null;
        } while (startKey != null);
    }

    public async Task<int> RebuildUserInteractionsFromLegacyAsync(CancellationToken cancellationToken = default)
    {
        var n = 0;
        var matchTable = Table.LoadTable(_dynamoDb, _matchesTable);
        var matchSearch = matchTable.Scan(new ScanFilter());
        do
        {
            cancellationToken.ThrowIfCancellationRequested();
            var batch = await matchSearch.GetNextSetAsync();
            foreach (var doc in batch)
            {
                var m = DocumentToMatch(doc);
                if (m.User1Liked)
                {
                    await UpsertUserInteractionAsync(m.UserId1, m.UserId2, m.IsMatched ? UserInteractionState.Matched : UserInteractionState.Sent);
                    n++;
                }
                if (m.User2Liked)
                {
                    await UpsertUserInteractionAsync(m.UserId2, m.UserId1, m.IsMatched ? UserInteractionState.Matched : UserInteractionState.Sent);
                    n++;
                }
            }
        } while (!matchSearch.IsDone);

        var passScan = Table.LoadTable(_dynamoDb, _discoverPassesTable).Scan(new ScanFilter());
        do
        {
            cancellationToken.ThrowIfCancellationRequested();
            var batch = await passScan.GetNextSetAsync();
            foreach (var doc in batch)
            {
                if (!doc.ContainsKey("userId") || !doc.ContainsKey("targetUserId")) continue;
                var uid = doc["userId"].AsString();
                var tid = doc["targetUserId"].AsString();
                if (string.IsNullOrEmpty(uid) || string.IsNullOrEmpty(tid)) continue;
                if (uid.StartsWith("__", StringComparison.Ordinal)) continue;

                var isSkipped = !doc.ContainsKey("isSkipped") || doc["isSkipped"].AsBoolean();
                var restored = doc.ContainsKey("restored") && doc["restored"].AsBoolean();
                var st = doc.ContainsKey("status") ? doc["status"].AsString() : "skipped";
                if (!isSkipped || restored || string.Equals(st, "active", StringComparison.OrdinalIgnoreCase))
                    continue;

                var existing = await GetUserInteractionStateAsync(uid, tid);
                if (existing == UserInteractionState.Sent || existing == UserInteractionState.Matched || existing == UserInteractionState.Cancelled)
                    continue;

                await UpsertUserInteractionAsync(uid, tid, UserInteractionState.Skipped);
                n++;
            }
        } while (!passScan.IsDone);

        return n;
    }

    private void ClearInteractionSyncThrottle(string userId)
    {
        if (!string.IsNullOrEmpty(userId))
            LastUserInteractionSyncMs.TryRemove(userId, out _);
    }

    public async Task<AdminDiscoverResetResult> AdminResetUserSkippedAsync(string userId, CancellationToken cancellationToken = default)
    {
        var result = new AdminDiscoverResetResult();
        if (string.IsNullOrWhiteSpace(userId)) return result;
        ClearInteractionSyncThrottle(userId);

        Dictionary<string, AttributeValue>? startKey = null;
        do
        {
            cancellationToken.ThrowIfCancellationRequested();
            var query = new QueryRequest
            {
                TableName = _userInteractionsTable,
                KeyConditionExpression = "userId = :u",
                FilterExpression = "#st = :sk",
                ExpressionAttributeNames = new Dictionary<string, string> { ["#st"] = "state" },
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                {
                    [":u"] = new AttributeValue { S = userId },
                    [":sk"] = new AttributeValue { S = UserInteractionState.Skipped }
                },
                ExclusiveStartKey = startKey
            };
            var response = await _dynamoDb.QueryAsync(query);
            foreach (var item in response.Items)
            {
                if (!item.TryGetValue("targetUserId", out var tid) || tid.S == null) continue;
                await _dynamoDb.DeleteItemAsync(new DeleteItemRequest
                {
                    TableName = _userInteractionsTable,
                    Key = new Dictionary<string, AttributeValue>
                    {
                        ["userId"] = new AttributeValue { S = userId },
                        ["targetUserId"] = new AttributeValue { S = tid.S }
                    }
                });
                result.SkippedInteractionsRemoved++;
            }
            startKey = response.LastEvaluatedKey is { Count: > 0 } ? response.LastEvaluatedKey : null;
        } while (startKey != null);

        result.DiscoverPassesRemoved = await DeleteAllDiscoverPassesForViewerAsync(userId, cancellationToken);
        return result;
    }

    public async Task<AdminDiscoverResetResult> AdminResetUserOutgoingSentAsync(string userId, CancellationToken cancellationToken = default)
    {
        var result = new AdminDiscoverResetResult();
        if (string.IsNullOrWhiteSpace(userId)) return result;
        ClearInteractionSyncThrottle(userId);

        Dictionary<string, AttributeValue>? startKey = null;
        do
        {
            cancellationToken.ThrowIfCancellationRequested();
            var query = new QueryRequest
            {
                TableName = _userInteractionsTable,
                KeyConditionExpression = "userId = :u",
                FilterExpression = "(#st = :sent OR #st = :matched)",
                ExpressionAttributeNames = new Dictionary<string, string> { ["#st"] = "state" },
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                {
                    [":u"] = new AttributeValue { S = userId },
                    [":sent"] = new AttributeValue { S = UserInteractionState.Sent },
                    [":matched"] = new AttributeValue { S = UserInteractionState.Matched }
                },
                ExclusiveStartKey = startKey
            };
            var response = await _dynamoDb.QueryAsync(query);
            foreach (var item in response.Items)
            {
                if (!item.TryGetValue("targetUserId", out var tid) || tid.S == null) continue;
                await _dynamoDb.DeleteItemAsync(new DeleteItemRequest
                {
                    TableName = _userInteractionsTable,
                    Key = new Dictionary<string, AttributeValue>
                    {
                        ["userId"] = new AttributeValue { S = userId },
                        ["targetUserId"] = new AttributeValue { S = tid.S }
                    }
                });
                result.OutgoingSentOrMatchedRemoved++;
            }
            startKey = response.LastEvaluatedKey is { Count: > 0 } ? response.LastEvaluatedKey : null;
        } while (startKey != null);

        return result;
    }

    public async Task<AdminDiscoverResetResult> AdminResetUserDiscoverStateAsync(string userId, bool removeMatchesAndChats, CancellationToken cancellationToken = default)
    {
        var result = new AdminDiscoverResetResult();
        if (string.IsNullOrWhiteSpace(userId)) return result;
        ClearInteractionSyncThrottle(userId);

        result.AllOutgoingInteractionsRemoved = await DeleteAllOutgoingInteractionsForUserAsync(userId, cancellationToken);
        result.ReverseInteractionsRemoved = await DeleteInteractionsWhereTargetUserIdAsync(userId, cancellationToken);
        result.DiscoverPassesRemoved = await DeleteAllDiscoverPassesForViewerAsync(userId, cancellationToken);

        try
        {
            await _profileService.PatchDiscoverLifecycleAsync(userId, new DiscoverLifecycleFlagsPatch
            {
                CanReplayDiscoverQueue = false,
                CanRecycleSkippedProfiles = false
            });
        }
        catch (Exception ex)
        {
            _logger.LogWarning(ex, "Admin reset: could not patch discover lifecycle for {UserId}", userId);
        }

        if (!removeMatchesAndChats)
        {
            // Otherwise EnsureLegacyInteractionsSyncedForUserAsync (next Discover load) re-upserts Sent from
            // pending match rows and those targets stay excluded — reset looked "broken".
            result.PendingNonMutualMatchesRemoved =
                await DeletePendingNonMutualMatchesForUserAsync(userId, cancellationToken);
            return result;
        }

        var matches = await ListMatchesInvolvingUserAsync(userId);
        foreach (var m in matches)
        {
            cancellationToken.ThrowIfCancellationRequested();
            try
            {
                result.ChatMessagesRemoved += await DeleteChatMessagesForThreadAsync(m.MatchId, cancellationToken);
                var threadsTable = Table.LoadTable(_dynamoDb, _chatThreadsTable);
                await threadsTable.DeleteItemAsync(m.MatchId);
                result.ChatThreadsRemoved++;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Admin reset: thread delete for match {MatchId}", m.MatchId);
            }

            try
            {
                var matchTable = Table.LoadTable(_dynamoDb, _matchesTable);
                await matchTable.DeleteItemAsync(m.MatchId);
                result.MatchesRemoved++;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Admin reset: match delete {MatchId}", m.MatchId);
            }
        }

        return result;
    }

    /// <summary>Removes match rows where both sides are not mutually matched (pending likes). Keeps mutual matches.</summary>
    private async Task<int> DeletePendingNonMutualMatchesForUserAsync(string userId, CancellationToken cancellationToken)
    {
        var n = 0;
        var matches = await ListMatchesInvolvingUserAsync(userId);
        var matchTable = Table.LoadTable(_dynamoDb, _matchesTable);
        foreach (var m in matches)
        {
            cancellationToken.ThrowIfCancellationRequested();
            if (m.IsMatched)
                continue;
            try
            {
                await matchTable.DeleteItemAsync(m.MatchId);
                n++;
            }
            catch (Exception ex)
            {
                _logger.LogWarning(ex, "Admin reset: could not delete pending match {MatchId}", m.MatchId);
            }
        }

        return n;
    }

    private async Task<int> DeleteAllOutgoingInteractionsForUserAsync(string userId, CancellationToken cancellationToken)
    {
        var n = 0;
        Dictionary<string, AttributeValue>? startKey = null;
        do
        {
            cancellationToken.ThrowIfCancellationRequested();
            var query = new QueryRequest
            {
                TableName = _userInteractionsTable,
                KeyConditionExpression = "userId = :u",
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                {
                    [":u"] = new AttributeValue { S = userId }
                },
                ExclusiveStartKey = startKey
            };
            var response = await _dynamoDb.QueryAsync(query);
            foreach (var item in response.Items)
            {
                if (!item.TryGetValue("targetUserId", out var tid) || tid.S == null) continue;
                await _dynamoDb.DeleteItemAsync(new DeleteItemRequest
                {
                    TableName = _userInteractionsTable,
                    Key = new Dictionary<string, AttributeValue>
                    {
                        ["userId"] = new AttributeValue { S = userId },
                        ["targetUserId"] = new AttributeValue { S = tid.S }
                    }
                });
                n++;
            }
            startKey = response.LastEvaluatedKey is { Count: > 0 } ? response.LastEvaluatedKey : null;
        } while (startKey != null);

        return n;
    }

    private async Task<int> DeleteInteractionsWhereTargetUserIdAsync(string targetUserId, CancellationToken cancellationToken)
    {
        var n = 0;
        Dictionary<string, AttributeValue>? startKey = null;
        do
        {
            cancellationToken.ThrowIfCancellationRequested();
            var scan = new ScanRequest
            {
                TableName = _userInteractionsTable,
                FilterExpression = "targetUserId = :t",
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                {
                    [":t"] = new AttributeValue { S = targetUserId }
                },
                ExclusiveStartKey = startKey
            };
            var response = await _dynamoDb.ScanAsync(scan);
            foreach (var item in response.Items)
            {
                if (!item.TryGetValue("userId", out var uid) || uid.S == null) continue;
                if (!item.TryGetValue("targetUserId", out var tid) || tid.S == null) continue;
                await _dynamoDb.DeleteItemAsync(new DeleteItemRequest
                {
                    TableName = _userInteractionsTable,
                    Key = new Dictionary<string, AttributeValue>
                    {
                        ["userId"] = new AttributeValue { S = uid.S },
                        ["targetUserId"] = new AttributeValue { S = tid.S }
                    }
                });
                n++;
            }
            startKey = response.LastEvaluatedKey is { Count: > 0 } ? response.LastEvaluatedKey : null;
        } while (startKey != null);

        return n;
    }

    private async Task<int> DeleteAllDiscoverPassesForViewerAsync(string userId, CancellationToken cancellationToken)
    {
        var n = 0;
        if (userId.StartsWith("__", StringComparison.Ordinal)) return 0;
        Dictionary<string, AttributeValue>? startKey = null;
        do
        {
            cancellationToken.ThrowIfCancellationRequested();
            var query = new QueryRequest
            {
                TableName = _discoverPassesTable,
                KeyConditionExpression = "userId = :u",
                ExpressionAttributeValues = new Dictionary<string, AttributeValue>
                {
                    [":u"] = new AttributeValue { S = userId }
                },
                ExclusiveStartKey = startKey
            };
            var response = await _dynamoDb.QueryAsync(query);
            foreach (var item in response.Items)
            {
                if (!item.TryGetValue("targetUserId", out var tid) || tid.S == null) continue;
                await _dynamoDb.DeleteItemAsync(new DeleteItemRequest
                {
                    TableName = _discoverPassesTable,
                    Key = new Dictionary<string, AttributeValue>
                    {
                        ["userId"] = new AttributeValue { S = userId },
                        ["targetUserId"] = new AttributeValue { S = tid.S }
                    }
                });
                n++;
            }
            startKey = response.LastEvaluatedKey is { Count: > 0 } ? response.LastEvaluatedKey : null;
        } while (startKey != null);

        return n;
    }

    private async Task<int> DeleteChatMessagesForThreadAsync(string threadId, CancellationToken cancellationToken)
    {
        var n = 0;
        var table = Table.LoadTable(_dynamoDb, _messagesTable);
        var scanFilter = new ScanFilter();
        scanFilter.AddCondition("threadId", ScanOperator.Equal, threadId);
        var search = table.Scan(scanFilter);
        do
        {
            cancellationToken.ThrowIfCancellationRequested();
            var batch = await search.GetNextSetAsync();
            foreach (var doc in batch)
            {
                if (!doc.ContainsKey("messageId")) continue;
                await table.DeleteItemAsync(doc);
                n++;
            }
        } while (!search.IsDone);

        return n;
    }
}
